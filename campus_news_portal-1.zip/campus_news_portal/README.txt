Campus News Portal - Group 1
--------------------------------
Files:
- index.html
- about.html
- categories.html
- contact.html
- styles.css
- script.js
- images/ (placeholder SVG images)

To host on GitHub Pages:
1. Create a new GitHub repository.
2. Push these files to the repository root (or gh-pages branch).
3. In repository Settings -> Pages, enable GitHub Pages from the main branch.
4. Visit https://<your-username>.github.io/<repo-name>/index.html

Replace placeholder group member names and images before submission.
