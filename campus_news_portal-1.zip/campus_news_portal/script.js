// script.js - simple interactivity for Campus News Portal

function searchArticles(){
  const q = document.getElementById('searchBar')?.value.toLowerCase().trim();
  if(q===undefined) return;
  const cards = document.querySelectorAll('#articles .card');
  cards.forEach(card=>{
    const title = card.getAttribute('data-title')?.toLowerCase() || '';
    if(!q || title.includes(q)){
      card.style.display = '';
    } else {
      card.style.display = 'none';
    }
  });
}

function validateForm(){
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();
  const category = document.getElementById('category').value;
  const result = document.getElementById('formResult');

  if(!name || !email || !message || !category){
    result.textContent = 'Please fill all fields before submitting.';
    result.style.color = 'crimson';
    return false;
  }

  // simple email check
  if(!email.includes('@') || email.length<6){
    result.textContent = 'Please enter a valid email.';
    result.style.color = 'crimson';
    return false;
  }

  result.textContent = 'Thank you! Your submission has been received (mock).';
  result.style.color = 'green';
  // clear form (mock)
  document.getElementById('submitForm').reset();
  return false; // prevent actual submit (no backend)
}
